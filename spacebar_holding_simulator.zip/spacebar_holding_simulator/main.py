import pygame
import time
import random
pygame.font.init()

WIDTH, HEIGHT = 1000, 700
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("spacebar holding simulator")

BG = pygame.image.load("bg.png")

P_WIDTH = 50
P_HEIGHT = 50

FONT = pygame.font.SysFont("arial", 30)

def draw(player, score):
    WINDOW.blit(BG, (0, 0))

    title = FONT.render("spacebar holding simulator", 1, "white")
    WINDOW.blit(title, (320, 10))

    score_text = FONT.render(f"score: {(score)}", 1, "white")
    WINDOW.blit(score_text, (10, 10))

    pygame.draw.rect(WINDOW, "orange", player)

    pygame.display.update()

def main():
    run = True

    player = pygame.Rect(500, HEIGHT - P_HEIGHT, P_WIDTH, P_HEIGHT)

    fps = pygame.time.Clock()

    score = 0

    while run:
        fps.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] and player.y - 5 >= 0:
            player.y -= 5
        
        if player.y - 5 <= 0:
            player.y = 700
            score += 1
            print(score)
            

        draw(player, score)

    pygame.quit()

if __name__ == "__main__":
    main()